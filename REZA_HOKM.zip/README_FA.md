# REZA HOKM 3D Android Online V42

این بسته، پروژه اندروید WebView به‌همراه نسخه آنلاین V42 بازی را در `app/src/main/assets/index.html` دارد.
برای ارتباط آنلاین، مجوز INTERNET به AndroidManifest اضافه شده است.

## ساخت APK
مخزن GitHub باید شامل این فایل ZIP و workflow ساخت APK در ریشه مخزن باشد.
پس از اجرای workflow، فایل APK در بخش Actions > Artifacts قرار می‌گیرد.
