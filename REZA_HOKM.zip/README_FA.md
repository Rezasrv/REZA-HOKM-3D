# REZA HOKM 3D Android V19

این پروژه نسخه V19 بازی را در یک WebView اندرویدی اجرا می‌کند. جهت برنامه عمودی (Portrait) است و رابط برای صفحه‌های موبایل تنظیم شده است.

## ساخت APK
- مخزن را در GitHub بارگذاری کنید.
- فایل `REZA_HOKM.zip` باید در ریشه مخزن باشد (در صورت استفاده از workflow قبلی).
- Workflow موجود در `.github/workflows/build-debug.yml` را اجرا کنید.
- خروجی آزمایشی در بخش Artifacts قرار می‌گیرد.

این پروژه APK آماده نیست؛ باید با Android Gradle Plugin ساخته و روی گوشی آزمایش شود.
