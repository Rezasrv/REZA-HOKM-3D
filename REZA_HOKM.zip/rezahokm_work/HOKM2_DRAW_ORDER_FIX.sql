-- REZA HOKM 3D: fix first picker after the 21 pair-draw choices.
-- Run this once in Supabase SQL Editor before testing the new two-player client.
create or replace function public.hokm2_discard(p_room_id uuid,p_cards text[])
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
declare v_uid uuid:=auth.uid(); v_seat smallint; v_state public.hokm2_states; v_hand text[]; v_expected integer; v_sub jsonb; v_first_count integer; v_first_seat smallint; v_card text; v_first_picker smallint;
begin
  if v_uid is null then raise exception 'ابتدا وارد حساب بازی شو'; end if;
  select seat_number into v_seat from public.hokm2_players where room_id=p_room_id and user_id=v_uid;
  if v_seat is null then raise exception 'عضو این اتاق نیستی'; end if;
  select * into v_state from public.hokm2_states where room_id=p_room_id for update;
  if v_state.game_phase<>'discarding' or v_state.current_turn<>v_seat then raise exception 'نوبت دورریختن کارت تو نیست'; end if;
  if p_cards is null or cardinality(p_cards) not in (2,3) then raise exception 'باید ۲ یا ۳ کارت انتخاب کنی'; end if;
  if (select count(distinct x) from unnest(p_cards) x)<>cardinality(p_cards) then raise exception 'کارت تکراری انتخاب شده است'; end if;
  select cards into v_hand from public.hokm2_hands where room_id=p_room_id and seat_number=v_seat for update;
  foreach v_card in array p_cards loop
    if not (v_card=any(v_hand)) then raise exception 'یکی از کارت‌های انتخابی در دستت نیست'; end if;
  end loop;
  v_sub:=coalesce(v_state.game_data->'discard_submissions','{}'::jsonb);
  if v_sub ? v_seat::text then raise exception 'قبلاً کارت‌هایت را دور ریخته‌ای'; end if;
  if v_state.hakim_seat=v_seat then
    update public.hokm2_states set game_data=game_data||jsonb_build_object('discard_submissions',v_sub||jsonb_build_object(v_seat::text,to_jsonb(p_cards)),'hakim_discard_count',cardinality(p_cards)),current_turn=1-v_seat,updated_at=now() where room_id=p_room_id;
    return jsonb_build_object('ok',true,'waiting_for_other_player',true);
  end if;
  v_first_seat:=v_state.hakim_seat;
  if not (v_sub ? v_first_seat::text) then raise exception 'ابتدا حاکم باید کارت‌هایش را دور بریزد'; end if;
  v_first_count:=jsonb_array_length(v_sub->v_first_seat::text);
  v_expected:=5-v_first_count;
  if cardinality(p_cards)<>v_expected then raise exception 'تعداد کارت دورریختنی باید % باشد',v_expected; end if;
  update public.hokm2_hands set cards=array(select c from unnest(v_hand) c where not (c=any(p_cards)) order by array_position(v_hand,c)),updated_at=now() where room_id=p_room_id and seat_number=v_seat;
  update public.hokm2_hands h set cards=array(select c from unnest(h.cards) c where not (c=any(array(select jsonb_array_elements_text(v_sub->v_first_seat::text)))) order by array_position(h.cards,c)),updated_at=now()
    where h.room_id=p_room_id and h.seat_number=v_first_seat;
  v_first_picker:=case when v_first_count=3 then v_first_seat else v_seat end;
  update public.hokm2_states set game_phase='drawing',current_turn=v_first_picker,
    game_data=game_data||jsonb_build_object('discard_submissions',v_sub||jsonb_build_object(v_seat::text,to_jsonb(p_cards)),'discarded_count',5,'draw_count',0,'stock_position',1,'draw_discarded',jsonb_build_array(),'first_picker',v_first_picker),updated_at=now()
    where room_id=p_room_id;
  return jsonb_build_object('ok',true,'phase','drawing','first_picker',v_first_picker);
end $$;

create or replace function public.hokm2_choose_draw(p_room_id uuid,p_keep_visible boolean)
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
declare v_uid uuid:=auth.uid(); v_seat smallint; v_state public.hokm2_states; v_pos integer; v_visible text; v_hidden text; v_hand text[]; v_kept text; v_discarded text; v_count integer; v_next integer; v_first_picker smallint;
begin
  if v_uid is null then raise exception 'ابتدا وارد حساب بازی شو'; end if;
  if p_keep_visible is null then raise exception 'انتخاب کارت مشخص نیست'; end if;
  select seat_number into v_seat from public.hokm2_players where room_id=p_room_id and user_id=v_uid;
  if v_seat is null then raise exception 'عضو این اتاق نیستی'; end if;
  select * into v_state from public.hokm2_states where room_id=p_room_id for update;
  if v_state.game_phase<>'drawing' or v_state.current_turn<>v_seat then raise exception 'نوبت انتخاب کارت تو نیست'; end if;
  v_count:=(v_state.game_data->>'draw_count')::integer;
  if v_count>=21 then raise exception 'مرحله برداشتن کارت تمام شده است'; end if;
  v_pos:=(v_state.game_data->>'stock_position')::integer;
  select card into v_visible from public.hokm2_stock where room_id=p_room_id and position=v_pos;
  select card into v_hidden from public.hokm2_stock where room_id=p_room_id and position=v_pos+1;
  if v_visible is null or v_hidden is null then raise exception 'کارت کافی در دسته باقی نمانده'; end if;
  v_kept:=case when p_keep_visible then v_visible else v_hidden end;
  v_discarded:=case when p_keep_visible then v_hidden else v_visible end;
  select cards into v_hand from public.hokm2_hands where room_id=p_room_id and seat_number=v_seat for update;
  update public.hokm2_hands set cards=array_append(v_hand,v_kept),updated_at=now() where room_id=p_room_id and seat_number=v_seat;
  v_count:=v_count+1; v_next:=1-v_seat;
  v_first_picker:=coalesce((v_state.game_data->>'first_picker')::smallint,v_state.hakim_seat);
  update public.hokm2_states set game_data=game_data||jsonb_build_object('draw_count',v_count,'stock_position',v_pos+2,'draw_discarded',coalesce(game_data->'draw_discarded','[]'::jsonb)||jsonb_build_array(v_discarded)),
    game_phase=case when v_count=21 then 'playing' else 'drawing' end,
    current_turn=case when v_count=21 then v_first_picker else v_next end,updated_at=now()
    where room_id=p_room_id;
  return jsonb_build_object('ok',true,'kept_card',v_kept,'draw_count',v_count,'phase',case when v_count=21 then 'playing' else 'drawing' end);
end $$;

revoke all on function public.hokm2_discard(uuid,text[]),public.hokm2_choose_draw(uuid,boolean) from public,anon;
grant execute on function public.hokm2_discard(uuid,text[]),public.hokm2_choose_draw(uuid,boolean) to authenticated;
