-- REZA HOKM 2P: first Ace dealt determines the first Hakem.
-- Run once in Supabase SQL Editor. Later hands already pass Hakem to the hand winner.
create or replace function public.hokm2_start_game(p_room_id uuid)
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
declare
  v_uid uuid:=auth.uid();
  v_host uuid;
  v_count integer;
  v_cards text[];
  v_hakim smallint;
  v_i integer;
  v_first_ace integer;
  v_pos integer;
begin
  if v_uid is null then raise exception 'ابتدا وارد حساب بازی شو'; end if;
  select host_id into v_host from public.hokm2_rooms where id=p_room_id for update;
  if v_host is null or v_host<>v_uid then raise exception 'فقط سازنده اتاق می‌تواند بازی را شروع کند'; end if;
  select count(*) into v_count from public.hokm2_players where room_id=p_room_id and is_ready=true;
  if v_count<>2 then raise exception 'هر دو بازیکن باید آماده باشند'; end if;
  if exists(select 1 from public.hokm2_states where room_id=p_room_id and game_phase<>'waiting') then raise exception 'بازی قبلاً شروع شده است'; end if;

  -- Shuffle until the first 10 dealt cards contain an Ace. Cards are dealt alternately:
  -- positions 1,3,5,7,9 to seat 0; positions 2,4,6,8,10 to seat 1.
  loop
    select array_agg(card order by random()) into v_cards from (
      select r||s as card
      from unnest(array['A','K','Q','J','10','9','8','7','6','5','4','3','2']) r
      cross join unnest(array['S','H','D','C']) s
    ) d;
    select min(i) into v_first_ace
    from generate_series(1,10) i
    where left(v_cards[i],length(v_cards[i])-1)='A';
    exit when v_first_ace is not null;
  end loop;
  v_hakim:=((v_first_ace-1)%2)::smallint;

  for v_i in 0..1 loop
    update public.hokm2_hands set cards=array[]::text[],updated_at=now()
      where room_id=p_room_id and seat_number=v_i;
    insert into public.hokm2_hands(room_id,seat_number,cards)
      values(p_room_id,v_i,array[v_cards[v_i+1],v_cards[v_i+3],v_cards[v_i+5],v_cards[v_i+7],v_cards[v_i+9]])
    on conflict(room_id,seat_number) do update set cards=excluded.cards,updated_at=now();
  end loop;

  delete from public.hokm2_stock where room_id=p_room_id;
  -- Keep the remaining 42 cards in deterministic stock order, skipping the dealt positions.
  v_i:=0;
  for v_pos in 11..52 loop
    v_i:=v_i+1;
    insert into public.hokm2_stock(room_id,position,card)
      values(p_room_id,v_i,v_cards[v_pos]);
  end loop;

  update public.hokm2_states
    set game_phase='choosing_trump',hakim_seat=v_hakim,current_turn=v_hakim,trump_suit=null,
      game_data=jsonb_build_object(
        'current_trick','[]'::jsonb,
        'trick_counts',jsonb_build_object('0',0,'1',0),
        'discarded','[]'::jsonb,
        'stock_position',1,
        'draw_count',0,
        'match_points',jsonb_build_object('0',0,'1',0),
        'first_ace_card',v_cards[v_first_ace],
        'first_ace_dealt_index',v_first_ace
      ),updated_at=now()
    where room_id=p_room_id;
  update public.hokm2_rooms set status='playing' where id=p_room_id;
  return jsonb_build_object('ok',true,'phase','choosing_trump','hakim_seat',v_hakim,
    'first_ace_card',v_cards[v_first_ace]);
end $$;

revoke all on function public.hokm2_start_game(uuid) from public,anon;
grant execute on function public.hokm2_start_game(uuid) to authenticated;
